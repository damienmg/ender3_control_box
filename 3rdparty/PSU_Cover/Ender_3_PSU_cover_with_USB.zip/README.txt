                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3225570
Ender 3 PSU cover with USB by mfau is licensed under the Creative Commons - Public Domain Dedication license.
http://creativecommons.org/publicdomain/zero/1.0/

# Summary

This is a cover for the stock Ender 3 power supply that:

* Adds a USB socket to power a Raspberry Pi running OctoPrint.
* Adds a divider between the mains AC section and the low voltage DC section of the cover, as well as a mount for the DC step down converter.
* Moves the IEC power socket to the rear, instead of the side. The switch is closest to the corner, so it is still easy enough to reach around and flick on/off if needed.
* Added a ledge to prevent the PSU from falling down into the cover and potentially shorting any wires.
* Moved the hole for the 24v printer cable to the side (instead of underneath), next to the USB, for easy routing.

Attached are files for the cover, a clip to hold the UBEC, and a version of the cover without the USB support (in case you don't need USB but want the other features).

Also attached are the original Fusion 360 design files so you can remix them for your own needs.

Requirements
============

The cover was specifically designed for the following:

* The [Hobbywing UBEC 3A 2-6S](http://www.hobbywing.com/goods.php?id=376), which is a DC step-down converter to convert the 24V DC from PSU to 5V DC (max 3A) for the Pi.
* A pair of [lugs](https://www.wiltronics.com.au/product/3284/slotted-terminal-3mm-stud/) (optional) to attach the UBEC to the PSU terminals. Alternatively you could probably just screw down the wire directly into the terminals.
* A USB panel socket. I just used [this cable](https://www.adafruit.com/product/908) and cut it near the end exposing the red (5V) and black (Gnd) wires.
* A single M2 screw, 8mm or longer, to fasten the UBEC clip to the cover.

I picked these simply because of the limited range and stock available in this country.

Note the Pi is very fussy about the power supply. The first DC step-down I tried (a [DFRobot model](https://www.dfrobot.com/product-752.html)) would drop to ~4.6v at load. I then tried this Hobbywing one, as it was listed on [ModMyPi](https://www.modmypi.com/power-1137/hobbywing-5v-3a-ubec-step-down-converter) as being suitable. Even so, I still get the occasional undervolt warning running a Pi 3B+. It has never caused any issues, but is something to be aware of if you decide to use it.

Installation
============

**WARNING** While you won't need to open the case of the PSU itself, it will require detaching the mains plug/switch from the PSU. Please take care, and do not undertake this mod if you are not sure what you are doing.

Disassembling the stock cover
-----------------------------

1. Unplug and detach the original PSU from the printer.
2. Unscrew the original plastic cover from the PSU.
3. Carefully open and make note of the wires connected to the terminals of the PSU.
4. Unscrew the terminals just enough to pull out all the wire lugs.
5. Unscrew and remove the mains socket/switch housing from the cover.

Assembling the new cover
------------------------

1. Attach the UBEC output wires to the USB panel mount; Red wire to Red wire, Black wire to Black wire, ignore the green/white wires used for USB data.
2. If you have a pair of lugs, attach them to the UBEC input wires using a crimp (or gently with a hammer).
3. Fasten the USB female panel mount into the holes in the cover.
4. Insert the UBEC into the printed UBEC mount and screw into place in the cover.
5. Insert the mains socket/switch housing that was removed from the stock cover, and screw into place at the rear of the new cover.
6. Insert the original 24v printer power cable through the hole in the new cover.
7. Screw in all wire lugs into the PSU terminals, taking care to ensure they use the same layout as noted when disassembling. For the new UBEC wires, use either of the two available pairs of terminals; red wire to V+ and black wire to V-. A photo of how mine looked at this stage is included above.
8. Gently edge the PSU back into the new cover, ensuring the wiring doesn't get snagged.
9. Fasten the cover screws, then reattach PSU to the printer.


# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: No
Infill: 25%

Notes: 
* The power socket hole may need support. I suggest enabling supports in Cura and use the Support Blocking tool to block out everything except the hole.